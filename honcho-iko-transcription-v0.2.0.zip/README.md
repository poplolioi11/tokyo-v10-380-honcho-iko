# 本朝醫考 · 東京大學藏本 V10:380

《本朝醫考》由黑川道祐編纂，分上、中、下三卷，以漢文記日本古代醫事、歷代醫家傳記、醫官制度、方技傳承和書目。東京大學藏本有原刻送假名、返點與補鈔總目錄。序署寬文三年（1663），刊記題田原仁左衛門，刊年原書未記。

The three-volume Honchō ikō, compiled by Kurokawa Dōyū, supplies biographies and institutional history of medicine in Japan. This edition follows Tokyo University General Library V10:380. The 1663 date belongs to the preface. All 113 manifest frames are indexed. The release includes a transcription of the printed text, manuscript table of contents, and visually read marks with their uncertainties.

- v0.2.0 對讀 182 個印本文字面，並逐面覆核 22 面補鈔目錄。共訂正 220 個正文欄或目錄欄位，另核定三處小字增補與訂正。候選與圖面證據見覆核說明。
- 原刻訓點、版心與後加朱墨保留 v0.1.0 觀察層及其錨點。逐符號獨立覆核尚未完成，部分小字只做辨識或疑處複查。
- 內容提供 TXT、JSON、TEI XML 與訓點 TSV。原刊為公有領域，新增編輯說明及資料編碼採 CC BY 4.0。尚待人工校對。
- 底本為東京大學總合圖書館 V10:380。轉錄整理曲宸宇（Chen-Yu Chu）。 [館藏底本](https://doi.org/10.20730/100273819) · [維基文庫](https://zh.wikisource.org/wiki/本朝醫考) · [ORCID](https://orcid.org/0009-0003-9738-6914)
